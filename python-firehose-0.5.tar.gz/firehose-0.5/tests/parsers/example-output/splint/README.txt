These files were generated using:

  splint \
      -strict \
      -csv unconditional-file-leak.csv \
      examples/unconditional-file-leak.c \
   > unconditional-file-leak.stdout \
   2> unconditional-file-leak.stderr
